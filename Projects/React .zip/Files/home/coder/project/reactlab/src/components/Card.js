import { Heading, HStack, Image, Text, VStack } from "@chakra-ui/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import React from "react";

const Card = ({ title, description, imageSrc }) => {
  return (
    <VStack
      spacing="0"
      align="start"
      bg="white"
      borderRadius="10px"
      overflow="hidden"
      width="100%"
      maxW="400px"
    >
      <Image src={imageSrc} alt={title} width="100%" height="auto" />

      <VStack align="start" spacing="12px" padding="16px">
        <Heading fontSize="18px" color="black">
          {title}
        </Heading>

        <Text fontSize="14px" color="gray.600">
          {description}
        </Text>

        <HStack spacing="6px" color="blue.500" fontWeight="semibold">
          <Text>See more</Text>
          <FontAwesomeIcon icon={faArrowRight} size="1x" />
        </HStack>
      </VStack>
    </VStack>
  );
};

const Projects = () => {
  return (
    <Box bg="#234236" minHeight="100vh" padding="40px">
      <Heading color="white" marginBottom="30px">
        Featured Projects
      </Heading>

      <VStack spacing="24px">
        <HStack spacing="24px" align="start">
          <Card
            title="React Space"
            description="Handy tool belt to create amazing AR components in a React app, with redux integration via middleware"
            imageSrc="https://via.placeholder.com/400x240"
          />
          <Card
            title="React Infinite Scroll"
            description="A scrollable bottom sheet with virtualisation support, native animations at 60 FPS and fully implemented in JS land 🔥"
            imageSrc="https://via.placeholder.com/400x240"
          />
        </HStack>

        <HStack spacing="24px" align="start">
          <Card
            title="Photo Gallery"
            description="A one-stop shop for photographers to share and monetize their photos, allowing them to have a second source of income"
            imageSrc="https://via.placeholder.com/400x240"
          />
          <Card
            title="Event planner"
            description="A mobile application for leisure seekers to discover unique events and activities in their city with a few taps"
            imageSrc="https://via.placeholder.com/400x240"
          />
        </HStack>
      </VStack>
    </Box>
  );
};

export default Card;

